<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <form class="form" action="script.php" method="post">
        Ingrese un numero mayor a cero: <input type="number" name="number" placeholder="Numero"><br>
        <input type="submit" value="Enviar">
    </form>
</body>
</html>



